ميزان التلاوة - مشروع Android تجريبي
تطبيق WebView أصلي يعرض واجهة HTML عربية وتسجيلًا صوتيًا وتحليل طبقة الصوت.

المشروع غير مبني وغير مختبر على جهاز حقيقي.
الواجهة تعمل محليًا بدون شبكة باستخدام WebViewAssetLoader HTTPS origin.
طلب الميكروفون يُعالج عبر onPermissionRequest + Android runtime permission.
ملفات التسجيل محفوظة في IndexedDB ضمن WebView إن كان مدعومًا، ويمكن إعادة تشغيلها داخل التطبيق.
زر حفظ الصوت/التنزيل من blob: URL لا يعمل بعد داخل APK؛ يحتاج واجهة JavaScript خاصة في إصدار لاحق.
تحليل Hz تقريبي ولا يقدم قياس جمال الأداء أو فحص التجويد.

Build (GitHub Actions): Upload this ZIP as project.zip to repository root, then create
.github/workflows/build.yml using the provided workflow, then run the workflow.
The Android build output is app/build/outputs/apk/debug/app-debug.apk.

License: This starter project is provided for adaptation and personal testing.
