ميزان التلاوة 1.3
New color palette: Prussian Blue #031130, Royal Blue #185DF1, Alice Blue #F3F7FE.
This is source code; APK compilation must be performed in GitHub Actions.
