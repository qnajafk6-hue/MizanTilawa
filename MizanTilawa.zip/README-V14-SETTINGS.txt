V1.4 Settings layout refresh. App entry at app/src/main/assets/index.html; voice and Quran features preserved. Build not validated on Android.
