ميزان التلاوة v1.1
تحديث الأيقونات بالاعتماد على Flaticon Uicons في حالة الاتصال بالإنترنت، مع رسومات احتياطية محلية.
الإسناد: Flaticon Uicons https://www.flaticon.com/uicons
الميزات السابقة محفوظة. يحتاج المشروع بناء APK عبر GitHub Actions.
